

<!-- Page Body Start-->
<div class="page-body-wrapper horizontal-menu">
  <!-- Page Sidebar Start-->
  <header class="main-nav">
    <!--<div class="sidebar-user text-center"><a class="setting-primary" href="javascript:void(0)"><i data-feather="settings"></i></a><img class="img-90 rounded-circle" src="../assets/images/dashboard/1.png" alt="">-->
    <!--  <div class="badge-bottom"><span class="badge badge-primary">New</span></div><a href="user-profile.html">-->
    <!--    <h6 class="mt-3 f-14 f-w-600"><?php echo $_SESSION['Username']; ?></h6></a>-->
    <!--  <p class="mb-0 font-roboto">Product</p>-->
    <!--</div>-->
<nav id="dept_1" class="none">
      <div class="main-navbar p-t-80" id="side">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="main-nav">           
          <ul class="nav-menu custom-scrollbar p-t-20"  id="myTab">
            <li class="back-btn">
              <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <br>
            <li class="dropdown"><a class="nav-link" href="../Dashboard/Home"><span>Dashboard</span></a>
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="index.html">Default</a></li>-->
              <!--  <li><a href="All_Product/all_product">All Products</a></li>-->
              <!--</ul>-->
            </li>
            <!--<li class="dropdown"><a class="nav-link" href="#"><span>Analytics</span></a>-->
            <!--  <ul class="nav-submenu menu-content">-->
            <!--    <li><a href="backup./Dashboard2/PnL.php">PNL</a></li>-->
            <!--    <li><a href="https://backup.thriftops.com/Dashboard2/hvcdb.php">HVC</a></li>-->
                
            <!--  </ul>-->
            <!--</li>-->
            <!--  <li class="dropdown"><a class="nav-link " href="../Vendor2/index"><span>Vendor</span></a>-->
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="../Vendor2/index">All Vendors</a></li>-->
              <!--</ul>-->
            <!--</li>-->
            <li  class="dropdown"><a class="nav-link menu-title  " href="javascript:void(0)"><span>Procurement</span></a>
              <ul class="nav-submenu menu-content">
                  <li><a href="../Vendor2/index">Vendor</a></li>
                <li id="purchase-requests" ><a href="../PR/PR_View">Purchase Requests</a></li>
                <li><a href="../PO/PO_View">Purchase Orders</a></li>
                <li><a href="../GRN/GRN_View">Goods Received Notes</a></li>
                <li><a href="../Batches/Batch_View">Batches</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Products</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../All_Product/View">All Products</a></li>
                <li><a href="../Upload/addAttribute.php">Add Category</a></li>
                <!--<li><a href="../ShopifyPush/addProduct">Add Product</a></li>-->
                <li><a href="../Upload/new.php">Product Listing</a></li>
                <!--<li><a href="../All_Product/Qc_reject">QC Rejected</a></li>-->
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Orders</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../ord/View">All Orders</a></li>
                <li><a href="../Booking/View">Booking</a></li>
                <li><a href="../Abandoned/View">Abandoned Carts</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Inventory</span></a>
              <ul class="nav-submenu menu-content">
                  
                <li><a href="../Warehouse/View">Warehouses</a></li>
                <!--<li><a href="../Warehouse/View_Allocation">Item Allocation</a></li>-->
                <li><a href="../Induction/New">Induction</a></li>
                <li><a href="../Pick/index.php">Pick List</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"></i><span>Dispatch</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Receiving/index.php">Pack List</a></li>
                <li><a href="../Loadsheet/Loadsheet">Loadsheet</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Returns</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Return/View.php">All Return</a></li>
                <li><a href="../Items_Return/index.php">Returning Items</a></li>
                <li><a href="https://backup.thriftops.com/Return/refunds">Refunds</a></li>
              </ul>
            </li>
           <li  class="dropdown"><a class="nav-link menu-title  " href="javascript:void(0)"><span>Reports</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Dashboard2/PnL.php">PNL</a></li>
                <li><a href="../Dashboard2/hvcdb.php">HVC</a></li>
                <li><a href="../Dashboard2/ordersreport.php">Orders by Couriers</a></li>

                <!--<li><a href="../PO/PO_View">Purchase Orders</a></li>-->
                <!--<li><a href="../GRN/GRN_View">Goods Received Notes</a></li>-->
                <!--<li><a href="../Batches/Batch_View">Batches</a></li>-->
              </ul>
            </li>
            <!--<li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"></i><span>Tracking</span>&nbsp;&nbsp;<span class="badge badge-primary">Coming Soon</span></a>-->
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="javascript:void(0)"></a></li>-->
              <!--  <li><a href="javascript:void(0)"></a></li>-->
              <!--</ul>-->
            <!--</li>-->
          </ul>
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
      </div>
    </nav>
<nav id="dept_2" class="none">
      <div class="main-navbar p-t-80" id="side">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="main-nav">           
          <ul class="nav-menu custom-scrollbar p-t-20"  id="myTab">
            <li class="back-btn">
              <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <br>
           
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Orders</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../ord/View">All Orders</a></li>
                <li><a href="../Booking/View">Booking</a></li>
                <li><a href="../Abandoned/View">Abandoned Carts</a></li>
              </ul>
            </li>
           
        
          </ul>
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
      </div>
    </nav>
<nav id="dept_3" class="none">
      <div class="main-navbar p-t-80" id="side">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="main-nav">           
          <ul class="nav-menu custom-scrollbar p-t-20"  id="myTab">
            <li class="back-btn">
              <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <br>
            <li class="dropdown"><a class="nav-link" href="../Dashboard/Home"><span>Dashboard</span></a>
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="index.html">Default</a></li>-->
              <!--  <li><a href="All_Product/all_product">All Products</a></li>-->
              <!--</ul>-->
            </li>
            <!--<li class="dropdown"><a class="nav-link" href="#"><span>Analytics</span></a>-->
            <!--  <ul class="nav-submenu menu-content">-->
            <!--    <li><a href="backup./Dashboard2/PnL.php">PNL</a></li>-->
            <!--    <li><a href="https://backup.thriftops.com/Dashboard2/hvcdb.php">HVC</a></li>-->
                
            <!--  </ul>-->
            <!--</li>-->
            <!--  <li class="dropdown"><a class="nav-link " href="../Vendor2/index"><span>Vendor</span></a>-->
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="../Vendor2/index">All Vendors</a></li>-->
              <!--</ul>-->
            <!--</li>-->
            <li  class="dropdown"><a class="nav-link menu-title  " href="javascript:void(0)"><span>Procurement</span></a>
              <ul class="nav-submenu menu-content">
                  <li><a href="../Vendor2/index">Vendor</a></li>
                <li id="purchase-requests" ><a href="../PR/PR_View">Purchase Requests</a></li>
                <li><a href="../PO/PO_View">Purchase Orders</a></li>
                <li><a href="../GRN/GRN_View">Goods Received Notes</a></li>
                <li><a href="../Batches/Batch_View">Batches</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Products</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../All_Product/View">All Products</a></li>
                <li><a href="../Upload/addAttribute.php">Add Category</a></li>
                <!--<li><a href="../ShopifyPush/addProduct">Add Product</a></li>-->
                <li><a href="../Upload/new.php">Product Listing</a></li>
                <!--<li><a href="../All_Product/Qc_reject">QC Rejected</a></li>-->
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Orders</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../ord/View">All Orders</a></li>
                <li><a href="../Booking/View">Booking</a></li>
                <li><a href="../Abandoned/View">Abandoned Carts</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Inventory</span></a>
              <ul class="nav-submenu menu-content">
                  
                <li><a href="../Warehouse/View">Warehouses</a></li>
                <!--<li><a href="../Warehouse/View_Allocation">Item Allocation</a></li>-->
                <li><a href="../Induction/New">Induction</a></li>
                <li><a href="../Pick/index">Pick List</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"></i><span>Dispatch</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Receiving/index.php">Pack List</a></li>
                <li><a href="../Loadsheet/Loadsheet">Loadsheet</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Returns</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Return/View.php">All Return</a></li>
                <li><a href="../Items_Return/index.php">Returning Items</a></li>
                <li><a href="https://backup.thriftops.com/Return/refunds">Refunds</a></li>
              </ul>
            </li>
           <li  class="dropdown"><a class="nav-link menu-title  " href="javascript:void(0)"><span>Reports</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Dashboard2/PnL.php">PNL</a></li>
                <li><a href="../Dashboard2/hvcdb.php">HVC</a></li>
                <li><a href="../Dashboard2/ordersreport.php">Orders by Couriers</a></li>
                <li><a href="../Dashboard2/frameReport.php">Couriers Bi</a></li>
                <li><a href="../orderbystatus/View.php">Orders By Status</a></li>

                <!--<li><a href="../PO/PO_View">Purchase Orders</a></li>-->
                <!--<li><a href="../GRN/GRN_View">Goods Received Notes</a></li>-->
                <!--<li><a href="../Batches/Batch_View">Batches</a></li>-->
              </ul>
            </li>
            <!--<li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"></i><span>Tracking</span>&nbsp;&nbsp;<span class="badge badge-primary">Coming Soon</span></a>-->
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="javascript:void(0)"></a></li>-->
              <!--  <li><a href="javascript:void(0)"></a></li>-->
              <!--</ul>-->
            <!--</li>-->
          </ul>
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
      </div>
    </nav>
<nav id="dept_4" class="none">
      <div class="main-navbar p-t-80" id="side">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="main-nav">           
          <ul class="nav-menu custom-scrollbar p-t-20"  id="myTab">
            <li class="back-btn">
              <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <br>
           
           
            
           
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Products</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../All_Product/View">All Products</a></li>
                <li><a href="../Upload/addAttribute.php">Add Category</a></li>
                <!--<li><a href="../ShopifyPush/addProduct">Add Product</a></li>-->
                <li><a href="../Upload/new.php">Product Listing</a></li>
                <!--<li><a href="../All_Product/Qc_reject">QC Rejected</a></li>-->
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Orders</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../ord/View">All Orders</a></li>
                <li><a href="../Booking/View">Booking</a></li>
                <li><a href="../Abandoned/View">Abandoned Carts</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Inventory</span></a>
              <ul class="nav-submenu menu-content">
                  
                <li><a href="../Warehouse/View">Warehouses</a></li>
                <!--<li><a href="../Warehouse/View_Allocation">Item Allocation</a></li>-->
                <li><a href="../Induction/New">Induction</a></li>
                <li><a href="../Pick/index.php">Pick List</a></li>
              </ul>
            </li>
           
          </ul>
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
      </div>
    </nav>
<nav id="dept_5" class="none">
      <div class="main-navbar p-t-80" id="side">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="main-nav">           
          <ul class="nav-menu custom-scrollbar p-t-20"  id="myTab">
            <li class="back-btn">
              <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <br>
           
          
            <li  class="dropdown"><a class="nav-link menu-title  " href="javascript:void(0)"><span>Procurement</span></a>
              <ul class="nav-submenu menu-content">
                  <li><a href="../Vendor2/index">Vendor</a></li>
                <li id="purchase-requests" ><a href="../PR/PR_View">Purchase Requests</a></li>
                <li><a href="../PO/PO_View">Purchase Orders</a></li>
                <li><a href="../GRN/GRN_View">Goods Received Notes</a></li>
                <li><a href="../Batches/Batch_View">Batches</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Products</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../All_Product/View">All Products</a></li>
                <li><a href="../Upload/addAttribute.php">Add Category</a></li>
                <!--<li><a href="../ShopifyPush/addProduct">Add Product</a></li>-->
                <li><a href="../Upload/new.php">Product Listing</a></li>
                <!--<li><a href="../All_Product/Qc_reject">QC Rejected</a></li>-->
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Orders</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../ord/View">All Orders</a></li>
                
              </ul>
            </li>
           
          </ul>
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
      </div>
    </nav>
<nav id="dept_6" class="none">
      <div class="main-navbar p-t-80" id="side">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="main-nav">           
          <ul class="nav-menu custom-scrollbar p-t-20"  id="myTab">
            <li class="back-btn">
              <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <br>
            <li class="dropdown"><a class="nav-link" href="../Dashboard/Home"><span>Dashboard</span></a>
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="index.html">Default</a></li>-->
              <!--  <li><a href="All_Product/all_product">All Products</a></li>-->
              <!--</ul>-->
            </li>
            <!--<li class="dropdown"><a class="nav-link" href="#"><span>Analytics</span></a>-->
            <!--  <ul class="nav-submenu menu-content">-->
            <!--    <li><a href="backup./Dashboard2/PnL.php">PNL</a></li>-->
            <!--    <li><a href="https://backup.thriftops.com/Dashboard2/hvcdb.php">HVC</a></li>-->
                
            <!--  </ul>-->
            <!--</li>-->
            <!--  <li class="dropdown"><a class="nav-link " href="../Vendor2/index"><span>Vendor</span></a>-->
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="../Vendor2/index">All Vendors</a></li>-->
              <!--</ul>-->
            <!--</li>-->
            <li  class="dropdown"><a class="nav-link menu-title  " href="javascript:void(0)"><span>Procurement</span></a>
              <ul class="nav-submenu menu-content">
                  <li><a href="../Vendor2/index">Vendor</a></li>
                <li id="purchase-requests" ><a href="../PR/PR_View">Purchase Requests</a></li>
                <li><a href="../PO/PO_View">Purchase Orders</a></li>
                <li><a href="../GRN/GRN_View">Goods Received Notes</a></li>
                <li><a href="../Batches/Batch_View">Batches</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Products</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../All_Product/View">All Products</a></li>
                <li><a href="../Upload/addAttribute.php">Add Category</a></li>
                <!--<li><a href="../ShopifyPush/addProduct">Add Product</a></li>-->
                <li><a href="../Upload/new.php">Product Listing</a></li>
                <!--<li><a href="../All_Product/Qc_reject">QC Rejected</a></li>-->
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Orders</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../ord/View">All Orders</a></li>
                <li><a href="../Booking/View">Booking</a></li>
                <li><a href="../Abandoned/View">Abandoned Carts</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Inventory</span></a>
              <ul class="nav-submenu menu-content">
                  
                <li><a href="../Warehouse/View">Warehouses</a></li>
                <!--<li><a href="../Warehouse/View_Allocation">Item Allocation</a></li>-->
                <li><a href="../Induction/New">Induction</a></li>
                <li><a href="../Pick/index">Pick List</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"></i><span>Dispatch</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Receiving/index.php">Pack List</a></li>
                <li><a href="../Loadsheet/Loadsheet">Loadsheet</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Returns</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Return/View.php">All Return</a></li>
                <li><a href="../Items_Return/index.php">Returning Items</a></li>
                <li><a href="https://backup.thriftops.com/Return/refunds">Refunds</a></li>
              </ul>
            </li>
           <!--<li  class="dropdown"><a class="nav-link menu-title  " href="javascript:void(0)"><span>Reports</span></a>-->
           <!--   <ul class="nav-submenu menu-content">-->
           <!--     <li><a href="../Dashboard2/PnL.php">PNL</a></li>-->
           <!--     <li><a href="../Dashboard2/hvcdb.php">HVC</a></li>-->
           <!--     <li><a href="../Dashboard2/ordersreport.php">Orders by Couriers</a></li>-->
                <!--<li><a href="../PO/PO_View">Purchase Orders</a></li>-->
                <!--<li><a href="../GRN/GRN_View">Goods Received Notes</a></li>-->
                <!--<li><a href="../Batches/Batch_View">Batches</a></li>-->
           <!--   </ul>-->
           <!-- </li>-->
            <!--<li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"></i><span>Tracking</span>&nbsp;&nbsp;<span class="badge badge-primary">Coming Soon</span></a>-->
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="javascript:void(0)"></a></li>-->
              <!--  <li><a href="javascript:void(0)"></a></li>-->
              <!--</ul>-->
            <!--</li>-->
          </ul>
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
      </div>
    </nav>
<nav id="dept_7" class="none">
      <div class="main-navbar p-t-80" id="side">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="main-nav">           
          <ul class="nav-menu custom-scrollbar p-t-20"  id="myTab">
            <li class="back-btn">
              <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <br>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Products</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../All_Product/View">All Products</a></li>
                <li><a href="../Upload/new.php">Product Listing</a></li>
              </ul>
            </li>
          </ul>
             
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
      </div>
</nav>
<nav id="dept_8" class="none">
      <div class="main-navbar p-t-80" id="side">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="main-nav">           
          <ul class="nav-menu custom-scrollbar p-t-20"  id="myTab">
            <li class="back-btn">
              <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <br>
            <li class="dropdown"><a class="nav-link" href="../Dashboard/Home"><span>Dashboard</span></a>
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="index.html">Default</a></li>-->
              <!--  <li><a href="All_Product/all_product">All Products</a></li>-->
              <!--</ul>-->
            </li>
            <!--<li class="dropdown"><a class="nav-link" href="#"><span>Analytics</span></a>-->
            <!--  <ul class="nav-submenu menu-content">-->
            <!--    <li><a href="backup./Dashboard2/PnL.php">PNL</a></li>-->
            <!--    <li><a href="https://backup.thriftops.com/Dashboard2/hvcdb.php">HVC</a></li>-->
                
            <!--  </ul>-->
            <!--</li>-->
            <!--  <li class="dropdown"><a class="nav-link " href="../Vendor2/index"><span>Vendor</span></a>-->
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="../Vendor2/index">All Vendors</a></li>-->
              <!--</ul>-->
            <!--</li>-->
            <li  class="dropdown"><a class="nav-link menu-title  " href="javascript:void(0)"><span>Procurement</span></a>
              <ul class="nav-submenu menu-content">
                  <li><a href="../Vendor2/index">Vendor</a></li>
                <li id="purchase-requests" ><a href="../PR/PR_View">Purchase Requests</a></li>
                <li><a href="../PO/PO_View">Purchase Orders</a></li>
                <li><a href="../GRN/GRN_View">Goods Received Notes</a></li>
                <li><a href="../Batches/Batch_View">Batches</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Products</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../All_Product/View">All Products</a></li>
                <li><a href="../Upload/addAttribute.php">Add Category</a></li>
                <!--<li><a href="../ShopifyPush/addProduct">Add Product</a></li>-->
                <li><a href="../Upload/new.php">Product Listing</a></li>
                <!--<li><a href="../All_Product/Qc_reject">QC Rejected</a></li>-->
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Orders</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../ord/View">All Orders</a></li>
                <li><a href="../Booking/View">Booking</a></li>
                <li><a href="../Abandoned/View">Abandoned Carts</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Inventory</span></a>
              <ul class="nav-submenu menu-content">
                  
                <li><a href="../Warehouse/View">Warehouses</a></li>
                <!--<li><a href="../Warehouse/View_Allocation">Item Allocation</a></li>-->
                <li><a href="../Induction/New">Induction</a></li>
                <li><a href="../Pick/index.php">Pick List</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"></i><span>Dispatch</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Receiving/index.php">Pack List</a></li>
                <li><a href="../Loadsheet/Loadsheet">Loadsheet</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Returns</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Return/View.php">All Return</a></li>
                <li><a href="../Items_Return/index.php">Returning Items</a></li>
                <li><a href="https://backup.thriftops.com/Return/refunds">Refunds</a></li>
              </ul>
            </li>
           <li  class="dropdown"><a class="nav-link menu-title  " href="javascript:void(0)"><span>Reports</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Dashboard2/PnL.php">PNL</a></li>
                <li><a href="../Dashboard2/hvcdb.php">HVC</a></li>
                <li><a href="../Dashboard2/ordersreport.php">Orders by Couriers</a></li>
                <!--<li><a href="../PO/PO_View">Purchase Orders</a></li>-->
                <!--<li><a href="../GRN/GRN_View">Goods Received Notes</a></li>-->
                <!--<li><a href="../Batches/Batch_View">Batches</a></li>-->
              </ul>
            </li>
            <!--<li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"></i><span>Tracking</span>&nbsp;&nbsp;<span class="badge badge-primary">Coming Soon</span></a>-->
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="javascript:void(0)"></a></li>-->
              <!--  <li><a href="javascript:void(0)"></a></li>-->
              <!--</ul>-->
            <!--</li>-->
          </ul>
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
      </div>
    </nav>
<nav id="dept_9" class="none">
      <div class="main-navbar p-t-80" id="side">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="main-nav">           
          <ul class="nav-menu custom-scrollbar p-t-20"  id="myTab">
            <li class="back-btn">
              <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <br>
            <li class="dropdown"><a class="nav-link" href="../Dashboard/Home"><span>Dashboard</span></a>
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="index.html">Default</a></li>-->
              <!--  <li><a href="All_Product/all_product">All Products</a></li>-->
              <!--</ul>-->
            </li>
            <!--<li class="dropdown"><a class="nav-link" href="#"><span>Analytics</span></a>-->
            <!--  <ul class="nav-submenu menu-content">-->
            <!--    <li><a href="backup./Dashboard2/PnL.php">PNL</a></li>-->
            <!--    <li><a href="https://backup.thriftops.com/Dashboard2/hvcdb.php">HVC</a></li>-->
                
            <!--  </ul>-->
            <!--</li>-->
            <!--  <li class="dropdown"><a class="nav-link " href="../Vendor2/index"><span>Vendor</span></a>-->
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="../Vendor2/index">All Vendors</a></li>-->
              <!--</ul>-->
            <!--</li>-->
            <li  class="dropdown"><a class="nav-link menu-title  " href="javascript:void(0)"><span>Procurement</span></a>
              <ul class="nav-submenu menu-content">
                  <li><a href="../Vendor2/index">Vendor</a></li>
                <li id="purchase-requests" ><a href="../PR/PR_View">Purchase Requests</a></li>
                <li><a href="../PO/PO_View">Purchase Orders</a></li>
                <li><a href="../GRN/GRN_View">Goods Received Notes</a></li>
                <li><a href="../Batches/Batch_View">Batches</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Products</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../All_Product/View">All Products</a></li>
                <li><a href="../Upload/addAttribute.php">Add Category</a></li>
                <!--<li><a href="../ShopifyPush/addProduct">Add Product</a></li>-->
                <li><a href="../Upload/new.php">Product Listing</a></li>
                <!--<li><a href="../All_Product/Qc_reject">QC Rejected</a></li>-->
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Orders</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../ord/View">All Orders</a></li>
                <li><a href="../Booking/View">Booking</a></li>
                <li><a href="../Abandoned/View">Abandoned Carts</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Inventory</span></a>
              <ul class="nav-submenu menu-content">
                  
                <li><a href="../Warehouse/View">Warehouses</a></li>
                <!--<li><a href="../Warehouse/View_Allocation">Item Allocation</a></li>-->
                <li><a href="../Induction/New">Induction</a></li>
                <li><a href="../Pick/index.php">Pick List</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"></i><span>Dispatch</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Receiving/index.php">Pack List</a></li>
                <li><a href="../Loadsheet/Loadsheet">Loadsheet</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Returns</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Return/View.php">All Return</a></li>
                <li><a href="../Items_Return/index.php">Returning Items</a></li>
                <li><a href="https://backup.thriftops.com/Return/refunds">Refunds</a></li>
              </ul>
            </li>
           <li  class="dropdown"><a class="nav-link menu-title  " href="javascript:void(0)"><span>Reports</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Dashboard2/PnL.php">PNL</a></li>
                <li><a href="../Dashboard2/hvcdb.php">HVC</a></li>
                <li><a href="../Dashboard2/ordersreport.php">Orders by Couriers</a></li>
                <!--<li><a href="../PO/PO_View">Purchase Orders</a></li>-->
                <!--<li><a href="../GRN/GRN_View">Goods Received Notes</a></li>-->
                <!--<li><a href="../Batches/Batch_View">Batches</a></li>-->
              </ul>
            </li>
            <!--<li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"></i><span>Tracking</span>&nbsp;&nbsp;<span class="badge badge-primary">Coming Soon</span></a>-->
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="javascript:void(0)"></a></li>-->
              <!--  <li><a href="javascript:void(0)"></a></li>-->
              <!--</ul>-->
            <!--</li>-->
          </ul>
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
      </div>
    </nav>
<nav id="dept_10" class="none">
      <div class="main-navbar p-t-80" id="side">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="main-nav">           
          <ul class="nav-menu custom-scrollbar p-t-20"  id="myTab">
            <li class="back-btn">
              <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <br>
            <li class="dropdown"><a class="nav-link" href="../Dashboard/Home"><span>Dashboard</span></a>
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="index.html">Default</a></li>-->
              <!--  <li><a href="All_Product/all_product">All Products</a></li>-->
              <!--</ul>-->
            </li>
            <!--<li class="dropdown"><a class="nav-link" href="#"><span>Analytics</span></a>-->
            <!--  <ul class="nav-submenu menu-content">-->
            <!--    <li><a href="backup./Dashboard2/PnL.php">PNL</a></li>-->
            <!--    <li><a href="https://backup.thriftops.com/Dashboard2/hvcdb.php">HVC</a></li>-->
                
            <!--  </ul>-->
            <!--</li>-->
            <!--  <li class="dropdown"><a class="nav-link " href="../Vendor2/index"><span>Vendor</span></a>-->
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="../Vendor2/index">All Vendors</a></li>-->
              <!--</ul>-->
            <!--</li>-->
            <li  class="dropdown"><a class="nav-link menu-title  " href="javascript:void(0)"><span>Procurement</span></a>
              <ul class="nav-submenu menu-content">
                  <li><a href="../Vendor2/index">Vendor</a></li>
                <li id="purchase-requests" ><a href="../PR/PR_View">Purchase Requests</a></li>
                <li><a href="../PO/PO_View">Purchase Orders</a></li>
                <li><a href="../GRN/GRN_View">Goods Received Notes</a></li>
                <li><a href="../Batches/Batch_View">Batches</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Products</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../All_Product/View">All Products</a></li>
                <li><a href="../Upload/addAttribute.php">Add Category</a></li>
                <!--<li><a href="../ShopifyPush/addProduct">Add Product</a></li>-->
                <li><a href="../Upload/new.php">Product Listing</a></li>
                <!--<li><a href="../All_Product/Qc_reject">QC Rejected</a></li>-->
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Orders</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../ord/View">All Orders</a></li>
                <li><a href="../Booking/View">Booking</a></li>
                <li><a href="../Abandoned/View">Abandoned Carts</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Inventory</span></a>
              <ul class="nav-submenu menu-content">
                  
                <li><a href="../Warehouse/View">Warehouses</a></li>
                <!--<li><a href="../Warehouse/View_Allocation">Item Allocation</a></li>-->
                <li><a href="../Induction/New">Induction</a></li>
                <li><a href="../Pick/index.php">Pick List</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"></i><span>Dispatch</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Receiving/index.php">Pack List</a></li>
                <li><a href="../Loadsheet/Loadsheet">Loadsheet</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Returns</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Return/View.php">All Return</a></li>
                <li><a href="../Items_Return/index.php">Returning Items</a></li>
                <li><a href="https://backup.thriftops.com/Return/refunds">Refunds</a></li>
              </ul>
            </li>
           <li  class="dropdown"><a class="nav-link menu-title  " href="javascript:void(0)"><span>Reports</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Dashboard2/PnL.php">PNL</a></li>
                <li><a href="../Dashboard2/hvcdb.php">HVC</a></li>
                <li><a href="../Dashboard2/ordersreport.php">Orders by Couriers</a></li>
                <!--<li><a href="../PO/PO_View">Purchase Orders</a></li>-->
                <!--<li><a href="../GRN/GRN_View">Goods Received Notes</a></li>-->
                <!--<li><a href="../Batches/Batch_View">Batches</a></li>-->
              </ul>
            </li>
            <!--<li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"></i><span>Tracking</span>&nbsp;&nbsp;<span class="badge badge-primary">Coming Soon</span></a>-->
              <!--<ul class="nav-submenu menu-content">-->
              <!--  <li><a href="javascript:void(0)"></a></li>-->
              <!--  <li><a href="javascript:void(0)"></a></li>-->
              <!--</ul>-->
            <!--</li>-->
          </ul>
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
      </div>
    </nav>
<nav id="dept_11" class="none">
      <div class="main-navbar p-t-80" id="side">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="main-nav">           
          <ul class="nav-menu custom-scrollbar p-t-20"  id="myTab">
            <li class="back-btn">
              <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <br>
        
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Orders</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../ord/View">All Orders</a></li>
                <li><a href="../Booking/View">Booking</a></li>
                <li><a href="../Abandoned/View">Abandoned Carts</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Inventory</span></a>
              <ul class="nav-submenu menu-content">
                  
                <li><a href="../Warehouse/View">Warehouses</a></li>
                <!--<li><a href="../Warehouse/View_Allocation">Item Allocation</a></li>-->
                <li><a href="../Induction/New">Induction</a></li>
                <li><a href="../Pick/index.php">Pick List</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"></i><span>Dispatch</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Receiving/index.php">Pack List</a></li>
                <li><a href="../Loadsheet/Loadsheet">Loadsheet</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
      </div>
    </nav>
<nav id="dept_12" class="none">
      <div class="main-navbar p-t-80" id="side">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="main-nav">           
          <ul class="nav-menu custom-scrollbar p-t-20"  id="myTab">
            <li class="back-btn">
              <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <br>
            <li  class="dropdown"><a class="nav-link menu-title  " href="javascript:void(0)"><span>Procurement</span></a>
              <ul class="nav-submenu menu-content">
                  <li><a href="../Vendor2/index">Vendor</a></li>
                <li id="purchase-requests" ><a href="../PR/PR_View">Purchase Requests</a></li>
                <li><a href="../PO/PO_View">Purchase Orders</a></li>
                <li><a href="../GRN/GRN_View">Goods Received Notes</a></li>
                <li><a href="../Batches/Batch_View">Batches</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Products</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../All_Product/View">All Products</a></li>
                <li><a href="../Upload/addAttribute.php">Add Category</a></li>
                <!--<li><a href="../ShopifyPush/addProduct">Add Product</a></li>-->
                <li><a href="../Upload/new.php">Product Listing</a></li>
                <!--<li><a href="../All_Product/Qc_reject">QC Rejected</a></li>-->
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Orders</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../ord/View">All Orders</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Inventory</span></a>
              <ul class="nav-submenu menu-content">
                  
                <li><a href="../Warehouse/View">Warehouses</a></li>
                <!--<li><a href="../Warehouse/View_Allocation">Item Allocation</a></li>-->
                <li><a href="../Induction/New">Induction</a></li>
                <li><a href="../Pick/index.php">Pick List</a></li>
              </ul>
            </li>
           
          </ul>
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
      </div>
    </nav>
<nav id="dept_13" class="none">
      <div class="main-navbar p-t-80" id="side">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="main-nav">           
          <ul class="nav-menu custom-scrollbar p-t-20"  id="myTab">
            <li class="back-btn">
              <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <br>
           
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Products</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../All_Product/View">All Products</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Inventory</span></a>
              <ul class="nav-submenu menu-content">
                  
                <li><a href="../Warehouse/View">Warehouses</a></li>
                <li><a href="../Induction/New">Induction</a></li>
                <li><a href="../Pick/index.php">Pick List</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
      </div>
    </nav>
<nav id="dept_14" class="none">
      <div class="main-navbar p-t-80" id="side">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="main-nav">           
          <ul class="nav-menu custom-scrollbar p-t-20"  id="myTab">
            <li class="back-btn">
              <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <br>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Orders</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../ord/View">All Orders</a></li>
                <li><a href="../Booking/View">Booking</a></li>
                <li><a href="../Abandoned/View">Abandoned Carts</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><span>Returns</span></a>
              <ul class="nav-submenu menu-content">
                <li><a href="../Return/View.php">All Return</a></li>
                <li><a href="../Items_Return/index.php">Returning Items</a></li>
                <li><a href="https://backup.thriftops.com/Return/refunds">Refunds</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
      </div>
    </nav>



  </header>
  <!-- Page Sidebar Ends-->
<input value="<?php echo $_SESSION['Username']; ?>" id="uname" style="display:none"/>  

<script>
    
    var uname = $("#uname").val()
    
var settings = {
  "url": "https://backup.thriftops.com/include/api/fetchid.php?id="+uname,
  "method": "POST",
  "timeout": 0,
  "processData": false,
  "mimeType": "multipart/form-data",
  "contentType": false,
};

$.ajax(settings).done(function (response) {
    
 
 if (response == 1) {
  var navElement = document.getElementById('dept_1');
  navElement.classList.remove('none');
  const purchaseRequestsLink = document.querySelector('#purchase-requests a');
  purchaseRequestsLink.href = '../PR/PR_Admin.php';
}
// console.log(response);
  if (response == 2) {
  var navElement = document.getElementById('dept_2');
  navElement.classList.remove('none');
  
//   if (!localStorage.getItem("redirected")) {
//     // Redirect to the desired URL
//     window.location.href = "https://backup.thriftops.com/ord/View";

//     // Set a flag in localStorage to indicate that redirection has occurred
//     localStorage.setItem("redirected", true);
//   }

 }
if (response == 3) {
  var navElement = document.getElementById('dept_3');
  navElement.classList.remove('none');
 
  

 }
 if (response == 8) {
  var navElement = document.getElementById('dept_8');
  navElement.classList.remove('none');

 }
 if (response == 9) {
  var navElement = document.getElementById('dept_9');
  navElement.classList.remove('none');

 }
if (response == 7) {
  var navElement = document.getElementById('dept_7');
  navElement.classList.remove('none');
 
//   if (!localStorage.getItem("redirected")) {
//     // Redirect to the desired URL
//     window.location.href = "https://backup.thriftops.com/All_Product/View";

//     // Set a flag in localStorage to indicate that redirection has occurred
//     localStorage.setItem("redirected", true);
//   }
 }
 if (response == 13) {
  var navElement = document.getElementById('dept_13');
  navElement.classList.remove('none');
  
//   if (!localStorage.getItem("redirected")) {
//     // Redirect to the desired URL
//     window.location.href = "https://backup.thriftops.com/All_Product/View";

//     // Set a flag in localStorage to indicate that redirection has occurred
//     localStorage.setItem("redirected", true);
//   }

 }
  if (response == 6) {
  var navElement = document.getElementById('dept_6');
  navElement.classList.remove('none');
  
//   if (!localStorage.getItem("redirected")) {
//     // Redirect to the desired URL
//     window.location.href = "https://backup.thriftops.com/ord/View";

//     // Set a flag in localStorage to indicate that redirection has occurred
//     localStorage.setItem("redirected", true);
//   }

 }
  if (response == 5) {
  var navElement = document.getElementById('dept_5');
  navElement.classList.remove('none');
  
//   if (!localStorage.getItem("redirected")) {
//     // Redirect to the desired URL
//     window.location.href = "https://backup.thriftops.com/Vendor2/index";

//     // Set a flag in localStorage to indicate that redirection has occurred
//     localStorage.setItem("redirected", true);
//   }

 }
  if (response == 4) {
  var navElement = document.getElementById('dept_4');
  navElement.classList.remove('none');
  
//   if (!localStorage.getItem("redirected")) {
//     // Redirect to the desired URL
//     window.location.href = "https://backup.thriftops.com/All_Product/View";

//     // Set a flag in localStorage to indicate that redirection has occurred
//     localStorage.setItem("redirected", true);
//   }

 }
  if (response == 10) {
  var navElement = document.getElementById('dept_10');
  navElement.classList.remove('none');

 }
  if (response == 11) {
  var navElement = document.getElementById('dept_11');
  navElement.classList.remove('none');
  
//   if (!localStorage.getItem("redirected")) {
//     // Redirect to the desired URL
//     window.location.href = "https://backup.thriftops.com/ord/View";

//     // Set a flag in localStorage to indicate that redirection has occurred
//     localStorage.setItem("redirected", true);
//   }

 }
  if (response == 12) {
  var navElement = document.getElementById('dept_12');
  navElement.classList.remove('none');
  
//   if (!localStorage.getItem("redirected")) {
//     // Redirect to the desired URL
//     window.location.href = "https://backup.thriftops.com/Vendor2/index";

//     // Set a flag in localStorage to indicate that redirection has occurred
//     localStorage.setItem("redirected", true);
//   }

 }
  if (response == 14) {
  var navElement = document.getElementById('dept_14');
  navElement.classList.remove('none');
  
//   if (!localStorage.getItem("redirected")) {
//     // Redirect to the desired URL
//     window.location.href = "https://backup.thriftops.com/ord/View";

//     // Set a flag in localStorage to indicate that redirection has occurred
//     localStorage.setItem("redirected", true);
//   }

 }
});


    
</script>


    

    
