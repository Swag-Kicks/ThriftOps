<?php
include_once('../vendor/autoload.php'); 

$client = new \GuzzleHttp\Client();
$headers = [
  'X-Shopify-Access-Token => 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',
  'Authorization => Bearer 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',
  'Content-Type' => 'application/json',
  'Cookie' => '_master_udr=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaWxtWkdFNE9ERmtOQzA0WlRaaUxUUmhaV010T0RJNVpTMWxZamhsWWpJMU5HUmhZemNHT2daRlJnPT0iLCJleHAiOiIyMDI1LTA0LTE4VDE4OjM4OjAxLjM5M1oiLCJwdXIiOiJjb29raWUuX21hc3Rlcl91ZHIifX0%3D--8fbfa7be93513c5bab937fa7df9806d427eed213; _secure_admin_session_id=6e43684edc3e79c529a7be8f3163be30; _secure_admin_session_id_csrf=6e43684edc3e79c529a7be8f3163be30'
];
$body = '{
  "order": {
    "line_items": [
      {
        "variant_id": "41514195747002",
        "quantity": 1
      },
      {
        "variant_id": "41121008419002",
        "quantity": 1
      }
    ],
    "customer": {
      "first_name": "King",
      "last_name": "Faraz"
    },
    "billing_address": {
      "first_name": "King",
      "last_name": "Faraz",
      "address1": "test",
      "phone": "03123456789",
      "city": "karahi",
      "country": "Pakistan"
    },
    "shipping_address": {
      "first_name": "King",
      "last_name": "Faraz",
      "address1": "test",
      "phone": "03123456789",
      "city": "karahi",
      "country": "Pakistan"
    },
    "financial_status": "pending"
  }
}';
$request =new \GuzzleHttp\Psr7\Request('POST', 'https://www-swag-kicks-com.myshopify.com/admin/api/2023-01/orders.json', $headers, $body);
$res = $client->sendAsync($request)->wait();
echo $res->getBody();



